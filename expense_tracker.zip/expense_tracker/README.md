# Expense Tracker (Python CLI)

Inovegen Internship — Task 2 (Python)

A command-line Expense Tracker that stores data in JSON and is built with
basic OOP (`Expense` and `ExpenseTracker` classes).

## Features

- **Add expense** — amount, category, date, description
- **View all expenses** — neatly formatted table-style listing
- **Search / filter** — by category, by date, or both
- **Totals** — overall total and category-wise totals
- **Update** an existing expense (press Enter to keep any field unchanged)
- **Delete** an expense (with confirmation prompt)
- **JSON persistence** — all data automatically saved to/loaded from `expenses.json`
- **Input validation** — rejects invalid amounts, dates, and empty required fields
  without crashing the program
- **Bonus features**
  - Monthly summary (expenses + total for a given `YYYY-MM`)
  - Category-wise spending summary (included in the Totals menu)
  - CSV export (`expenses_export.csv` by default)

## Requirements

- Python 3.7+ (no external libraries needed — uses only the standard library:
  `json`, `os`, `csv`, `datetime`)

## Setup

1. Make sure Python 3 is installed:
   ```bash
   python3 --version
   ```
2. Place `expense_tracker.py` and (optionally) the sample `expenses.json`
   in the same folder.

## Running the Program

```bash
python3 expense_tracker.py
```

You'll see a menu:

```
========== EXPENSE TRACKER ==========
1. Add expense
2. View all expenses
3. Search / filter expenses
4. View totals (overall & by category)
5. Update an expense
6. Delete an expense
7. Monthly summary (bonus)
8. Export to CSV (bonus)
0. Exit
======================================
```

Enter the number of the option you want and follow the prompts.

- Dates must be entered as `YYYY-MM-DD` (e.g. `2026-09-25`).
- Amounts must be positive numbers (e.g. `12.50`).
- When updating an expense, the current value is shown in brackets —
  press Enter without typing anything to keep it unchanged.
- All changes (add/update/delete) are saved to `expenses.json` immediately.

## Data File

Expenses are stored in `expenses.json` in the same folder as the script, as
a list of objects:

```json
{
    "id": 1,
    "amount": 45.5,
    "category": "Food",
    "date": "2026-09-01",
    "description": "Weekly groceries"
}
```

If `expenses.json` does not exist, the program creates one automatically
the first time you add an expense.

## Project Structure

```
.
├── expense_tracker.py   # Main application (Expense & ExpenseTracker classes, CLI)
├── expenses.json         # Sample data file
└── README.md             # This file
```

## Notes

- The `Expense` class represents a single expense record and knows how to
  convert itself to/from a dictionary for JSON storage.
- The `ExpenseTracker` class manages the full collection: loading, saving,
  adding, searching, updating, deleting, and computing totals.
- All user input goes through validation helper functions
  (`prompt_amount`, `prompt_category`, `prompt_date`, `prompt_description`,
  `prompt_int`) so invalid input is re-prompted rather than crashing the app.
