#!/usr/bin/env python3
"""
Expense Tracker
----------------
A command-line Expense Tracker application using JSON storage and OOP.

Inovegen Internship - Task 2 (Python)

Features:
    - Add expenses (amount, category, date, description)
    - View all expenses
    - Search / filter by category or date
    - Calculate total and category-wise totals
    - Update and delete an expense
    - Save / load data using JSON
    - Input validation and error handling
    - Bonus: monthly summary, category-wise summary, CSV export

Author: (your name here)
"""

import json
import os
import csv
from datetime import datetime


DATA_FILE = "expenses.json"
DATE_FORMAT = "%Y-%m-%d"


class Expense:
    """Represents a single expense entry."""

    def __init__(self, expense_id, amount, category, date, description):
        self.id = expense_id
        self.amount = amount
        self.category = category
        self.date = date  # stored as string 'YYYY-MM-DD'
        self.description = description

    def to_dict(self):
        """Convert the Expense object to a dictionary for JSON storage."""
        return {
            "id": self.id,
            "amount": self.amount,
            "category": self.category,
            "date": self.date,
            "description": self.description,
        }

    @staticmethod
    def from_dict(data):
        """Create an Expense object from a dictionary."""
        return Expense(
            expense_id=data["id"],
            amount=data["amount"],
            category=data["category"],
            date=data["date"],
            description=data["description"],
        )

    def __str__(self):
        return (
            f"[{self.id}] {self.date} | {self.category:<15} | "
            f"${self.amount:>10.2f} | {self.description}"
        )


class ExpenseTracker:
    """Manages a collection of Expense objects, including persistence."""

    def __init__(self, data_file=DATA_FILE):
        self.data_file = data_file
        self.expenses = []
        self.next_id = 1
        self.load_expenses()

    # ---------------------------------------------------------------
    # Persistence
    # ---------------------------------------------------------------
    def load_expenses(self):
        """Load expenses from the JSON file, if it exists."""
        if not os.path.exists(self.data_file):
            self.expenses = []
            self.next_id = 1
            return

        try:
            with open(self.data_file, "r", encoding="utf-8") as f:
                raw_data = json.load(f)
            self.expenses = [Expense.from_dict(item) for item in raw_data]
            if self.expenses:
                self.next_id = max(e.id for e in self.expenses) + 1
            else:
                self.next_id = 1
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            print(f"Warning: could not read '{self.data_file}' ({e}). "
                  f"Starting with an empty expense list.")
            self.expenses = []
            self.next_id = 1

    def save_expenses(self):
        """Save the current list of expenses to the JSON file."""
        try:
            with open(self.data_file, "w", encoding="utf-8") as f:
                json.dump(
                    [e.to_dict() for e in self.expenses], f, indent=4
                )
        except OSError as e:
            print(f"Error: could not save data ({e}).")

    # ---------------------------------------------------------------
    # Core operations
    # ---------------------------------------------------------------
    def add_expense(self, amount, category, date, description):
        expense = Expense(self.next_id, amount, category, date, description)
        self.expenses.append(expense)
        self.next_id += 1
        self.save_expenses()
        return expense

    def view_all(self):
        return list(self.expenses)

    def find_by_id(self, expense_id):
        for e in self.expenses:
            if e.id == expense_id:
                return e
        return None

    def search(self, category=None, date=None):
        """Filter expenses by category and/or date (both optional)."""
        results = self.expenses
        if category:
            results = [
                e for e in results
                if e.category.lower() == category.lower()
            ]
        if date:
            results = [e for e in results if e.date == date]
        return results

    def total(self):
        return sum(e.amount for e in self.expenses)

    def totals_by_category(self):
        totals = {}
        for e in self.expenses:
            totals[e.category] = totals.get(e.category, 0) + e.amount
        return totals

    def update_expense(self, expense_id, amount=None, category=None,
                        date=None, description=None):
        expense = self.find_by_id(expense_id)
        if not expense:
            return None
        if amount is not None:
            expense.amount = amount
        if category is not None:
            expense.category = category
        if date is not None:
            expense.date = date
        if description is not None:
            expense.description = description
        self.save_expenses()
        return expense

    def delete_expense(self, expense_id):
        expense = self.find_by_id(expense_id)
        if not expense:
            return False
        self.expenses.remove(expense)
        self.save_expenses()
        return True

    # ---------------------------------------------------------------
    # Bonus features
    # ---------------------------------------------------------------
    def monthly_summary(self, year_month):
        """year_month format: 'YYYY-MM'. Returns matching expenses + total."""
        results = [e for e in self.expenses if e.date.startswith(year_month)]
        return results, sum(e.amount for e in results)

    def export_csv(self, filename="expenses_export.csv"):
        try:
            with open(filename, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["id", "amount", "category", "date", "description"])
                for e in self.expenses:
                    writer.writerow([e.id, e.amount, e.category, e.date, e.description])
            return filename
        except OSError as e:
            print(f"Error exporting CSV: {e}")
            return None


# =====================================================================
# Input validation helpers
# =====================================================================
def prompt_amount(current=None):
    while True:
        suffix = f" [{current}]" if current is not None else ""
        raw = input(f"Amount{suffix}: ").strip()
        if raw == "" and current is not None:
            return current
        try:
            value = float(raw)
            if value <= 0:
                print("Amount must be a positive number. Try again.")
                continue
            return round(value, 2)
        except ValueError:
            print("Invalid amount. Please enter a number (e.g. 12.50).")


def prompt_category(current=None):
    while True:
        suffix = f" [{current}]" if current is not None else ""
        raw = input(f"Category{suffix}: ").strip()
        if raw == "" and current is not None:
            return current
        if raw == "":
            print("Category cannot be empty. Try again.")
            continue
        return raw


def prompt_date(current=None):
    while True:
        suffix = f" [{current}]" if current is not None else ""
        raw = input(f"Date (YYYY-MM-DD){suffix}: ").strip()
        if raw == "" and current is not None:
            return current
        try:
            datetime.strptime(raw, DATE_FORMAT)
            return raw
        except ValueError:
            print("Invalid date format. Please use YYYY-MM-DD (e.g. 2026-09-25).")


def prompt_description(current=None):
    suffix = f" [{current}]" if current is not None else ""
    raw = input(f"Description{suffix}: ").strip()
    if raw == "" and current is not None:
        return current
    return raw if raw else "(no description)"


def prompt_int(message):
    while True:
        raw = input(message).strip()
        try:
            return int(raw)
        except ValueError:
            print("Please enter a valid whole number (ID).")


# =====================================================================
# CLI Menu
# =====================================================================
def print_expenses(expense_list):
    if not expense_list:
        print("No expenses found.")
        return
    print("-" * 70)
    for e in expense_list:
        print(e)
    print("-" * 70)


def menu_add(tracker):
    print("\n-- Add Expense --")
    amount = prompt_amount()
    category = prompt_category()
    date = prompt_date()
    description = prompt_description()
    expense = tracker.add_expense(amount, category, date, description)
    print(f"Added expense with ID {expense.id}.")


def menu_view_all(tracker):
    print("\n-- All Expenses --")
    print_expenses(tracker.view_all())


def menu_search(tracker):
    print("\n-- Search / Filter --")
    print("Leave a field blank to skip it.")
    category = input("Category: ").strip() or None
    date = input("Date (YYYY-MM-DD): ").strip() or None
    results = tracker.search(category=category, date=date)
    print_expenses(results)


def menu_totals(tracker):
    print("\n-- Totals --")
    print(f"Total spent: ${tracker.total():.2f}")
    by_cat = tracker.totals_by_category()
    if by_cat:
        print("\nCategory-wise totals:")
        for cat, amt in sorted(by_cat.items()):
            print(f"  {cat:<20} ${amt:.2f}")
    else:
        print("No expenses recorded yet.")


def menu_update(tracker):
    print("\n-- Update Expense --")
    expense_id = prompt_int("Enter the ID of the expense to update: ")
    expense = tracker.find_by_id(expense_id)
    if not expense:
        print(f"No expense found with ID {expense_id}.")
        return
    print("Current values shown in brackets. Press Enter to keep them.")
    amount = prompt_amount(current=expense.amount)
    category = prompt_category(current=expense.category)
    date = prompt_date(current=expense.date)
    description = prompt_description(current=expense.description)
    tracker.update_expense(expense_id, amount, category, date, description)
    print("Expense updated.")


def menu_delete(tracker):
    print("\n-- Delete Expense --")
    expense_id = prompt_int("Enter the ID of the expense to delete: ")
    expense = tracker.find_by_id(expense_id)
    if not expense:
        print(f"No expense found with ID {expense_id}.")
        return
    confirm = input(f"Delete '{expense}'? (y/n): ").strip().lower()
    if confirm == "y":
        tracker.delete_expense(expense_id)
        print("Expense deleted.")
    else:
        print("Cancelled.")


def menu_monthly_summary(tracker):
    print("\n-- Monthly Summary --")
    while True:
        ym = input("Enter month (YYYY-MM): ").strip()
        try:
            datetime.strptime(ym, "%Y-%m")
            break
        except ValueError:
            print("Invalid format. Please use YYYY-MM (e.g. 2026-09).")
    results, total = tracker.monthly_summary(ym)
    print_expenses(results)
    print(f"Total for {ym}: ${total:.2f}")


def menu_export_csv(tracker):
    print("\n-- Export to CSV --")
    filename = input("Filename [expenses_export.csv]: ").strip() or "expenses_export.csv"
    result = tracker.export_csv(filename)
    if result:
        print(f"Exported to '{result}'.")


MENU_TEXT = """
========== EXPENSE TRACKER ==========
1. Add expense
2. View all expenses
3. Search / filter expenses
4. View totals (overall & by category)
5. Update an expense
6. Delete an expense
7. Monthly summary (bonus)
8. Export to CSV (bonus)
0. Exit
======================================
"""


def main():
    tracker = ExpenseTracker()
    actions = {
        "1": lambda: menu_add(tracker),
        "2": lambda: menu_view_all(tracker),
        "3": lambda: menu_search(tracker),
        "4": lambda: menu_totals(tracker),
        "5": lambda: menu_update(tracker),
        "6": lambda: menu_delete(tracker),
        "7": lambda: menu_monthly_summary(tracker),
        "8": lambda: menu_export_csv(tracker),
    }

    print("Welcome to the Expense Tracker!")
    while True:
        print(MENU_TEXT)
        choice = input("Choose an option: ").strip()
        if choice == "0":
            print("Goodbye!")
            break
        action = actions.get(choice)
        if action:
            try:
                action()
            except KeyboardInterrupt:
                print("\nCancelled.")
            except Exception as e:  # noqa: BLE001 - keep app from crashing
                print(f"An unexpected error occurred: {e}")
        else:
            print("Invalid option. Please choose a number from the menu.")


if __name__ == "__main__":
    main()
