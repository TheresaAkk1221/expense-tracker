"""Student Record Management System (CLI)
Inovegen Internship - Task 3

Features: add, view, search, update, delete student records,
JSON persistence, input validation, and a marks summary.
"""

import json
import os
import re

DATA_FILE = "students.json"
ID_PATTERN = re.compile(r"^[A-Za-z0-9]{3,10}$")


# ---------- File handling ----------
def load_records(path=DATA_FILE):
    """Load records from JSON. Returns [] if file is missing or corrupted."""
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("Data file must contain a list.")
        return data
    except (json.JSONDecodeError, ValueError, OSError) as e:
        print(f"Warning: could not read '{path}' ({e}). Starting with no records.")
        return []


def save_records(records, path=DATA_FILE):
    """Save records to JSON."""
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2)
        return True
    except OSError as e:
        print(f"Error: could not save data ({e}).")
        return False


# ---------- Validation / input helpers ----------
def find_student(records, student_id):
    for r in records:
        if r["id"].lower() == student_id.lower():
            return r
    return None


def input_required(prompt):
    """Ask until a non-empty value is entered."""
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("  This field is required.")


def input_id(records, must_exist=False, must_be_new=False):
    """Ask for a valid student ID (3-10 letters/digits)."""
    while True:
        sid = input("Student ID (3-10 letters/digits): ").strip()
        if not ID_PATTERN.match(sid):
            print("  Invalid ID. Use 3-10 letters or digits, no spaces.")
            continue
        exists = find_student(records, sid) is not None
        if must_be_new and exists:
            print("  That ID already exists.")
            continue
        if must_exist and not exists:
            print("  No student found with that ID.")
            return None
        return sid


def input_name(prompt="Name: "):
    while True:
        name = input_required(prompt)
        if all(ch.isalpha() or ch in " .'-" for ch in name):
            return name.title()
        print("  Name may contain only letters, spaces, . ' and -")


def input_marks(prompt="Marks (0-100): "):
    while True:
        raw = input(prompt).strip()
        try:
            marks = float(raw)
        except ValueError:
            print("  Marks must be a number.")
            continue
        if 0 <= marks <= 100:
            return round(marks, 2)
        print("  Marks must be between 0 and 100.")


def calc_grade(marks):
    if marks >= 90:
        return "A+"
    if marks >= 80:
        return "A"
    if marks >= 70:
        return "B"
    if marks >= 60:
        return "C"
    if marks >= 50:
        return "D"
    return "F"


# ---------- Display ----------
def print_table(rows):
    if not rows:
        print("No records to show.")
        return
    print(f"\n{'ID':<12}{'Name':<24}{'Course':<20}{'Marks':>7}{'Grade':>7}")
    print("-" * 70)
    for r in rows:
        print(f"{r['id']:<12}{r['name']:<24}{r['course']:<20}"
              f"{r['marks']:>7.1f}{calc_grade(r['marks']):>7}")
    print()


# ---------- Operations ----------
def add_student(records):
    sid = input_id(records, must_be_new=True)
    name = input_name()
    course = input_required("Course: ").title()
    marks = input_marks()
    records.append({"id": sid, "name": name, "course": course, "marks": marks})
    if save_records(records):
        print("Student added.")


def view_students(records):
    print_table(sorted(records, key=lambda r: r["id"].lower()))


def search_students(records):
    query = input_required("Search by ID or name: ").lower()
    results = [r for r in records
               if query in r["id"].lower() or query in r["name"].lower()]
    print_table(results)


def update_student(records):
    sid = input_id(records, must_exist=True)
    if sid is None:
        return
    s = find_student(records, sid)
    print("Leave blank to keep the current value.")
    new_name = input(f"Name [{s['name']}]: ").strip()
    if new_name:
        if all(ch.isalpha() or ch in " .'-" for ch in new_name):
            s["name"] = new_name.title()
        else:
            print("  Invalid name, keeping old value.")
    new_course = input(f"Course [{s['course']}]: ").strip()
    if new_course:
        s["course"] = new_course.title()
    while True:
        raw = input(f"Marks [{s['marks']}]: ").strip()
        if not raw:
            break
        try:
            m = float(raw)
            if 0 <= m <= 100:
                s["marks"] = round(m, 2)
                break
            print("  Marks must be between 0 and 100.")
        except ValueError:
            print("  Marks must be a number.")
    if save_records(records):
        print("Student updated.")


def delete_student(records):
    sid = input_id(records, must_exist=True)
    if sid is None:
        return
    s = find_student(records, sid)
    confirm = input(f"Delete {s['name']} ({s['id']})? (y/n): ").strip().lower()
    if confirm == "y":
        records.remove(s)
        if save_records(records):
            print("Student deleted.")
    else:
        print("Cancelled.")


def show_summary(records):
    if not records:
        print("No records available for a summary.")
        return
    marks = [r["marks"] for r in records]
    top = max(records, key=lambda r: r["marks"])
    low = min(records, key=lambda r: r["marks"])
    print("\n--- Summary ---")
    print(f"Total students : {len(records)}")
    print(f"Average marks  : {sum(marks) / len(marks):.2f}")
    print(f"Highest marks  : {top['marks']} ({top['name']})")
    print(f"Lowest marks   : {low['marks']} ({low['name']})\n")


# ---------- Main menu ----------
MENU = """
===== Student Record Management =====
1. Add student
2. View all students
3. Search student
4. Update student
5. Delete student
6. Summary (average / highest / lowest)
7. Exit
"""


def main():
    records = load_records()
    actions = {
        "1": add_student,
        "2": view_students,
        "3": search_students,
        "4": update_student,
        "5": delete_student,
        "6": show_summary,
    }
    while True:
        print(MENU)
        try:
            choice = input("Choose an option (1-7): ").strip()
            if choice == "7":
                print("Goodbye!")
                break
            action = actions.get(choice)
            if action:
                action(records)
            else:
                print("Invalid choice. Enter a number from 1 to 7.")
        except (KeyboardInterrupt, EOFError):
            print("\nExiting. Goodbye!")
            break


if __name__ == "__main__":
    main()
