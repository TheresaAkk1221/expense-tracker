# Student Record Management System (CLI)

Inovegen Internship — Task 3 (Python Programming)

A command-line app to manage student records with persistent JSON storage.

## Setup
- Requires **Python 3.8+**. No external libraries needed.
- Place `student_manager.py` and `students.json` in the same folder.

## Run
```bash
python student_manager.py
```
If `students.json` doesn't exist, it is created automatically on the first save.

## Features
1. **Add** a student (ID, name, course, marks)
2. **View** all students in a formatted table with grades
3. **Search** by ID or name (partial, case-insensitive)
4. **Update** any field (press Enter to keep current value)
5. **Delete** with confirmation
6. **Summary**: total students, average, highest and lowest marks
7. **Exit**

## Validation & Error Handling
- IDs: 3–10 letters/digits, must be unique (case-insensitive)
- Names: letters, spaces, `. ' -` only; required fields cannot be blank
- Marks: numeric, between 0 and 100
- Invalid menu choices are rejected without crashing
- Missing or corrupted data file is handled gracefully
- Ctrl+C / Ctrl+D exits cleanly

## Grading Scale
A+ ≥ 90 · A ≥ 80 · B ≥ 70 · C ≥ 60 · D ≥ 50 · F < 50

## Data Format
```json
{"id": "S101", "name": "Ayesha Khan", "course": "Computer Science", "marks": 88.5}
```

## Code Structure
- File handling: `load_records`, `save_records`
- Validation: `input_id`, `input_name`, `input_marks`, `input_required`
- Operations: `add_student`, `view_students`, `search_students`, `update_student`, `delete_student`, `show_summary`
- Entry point: `main()`
