# CLI Contact Book

A menu-driven command-line contact manager built with core Python — no external
dependencies. Built for Inovegen Internship Program 2026, Week 1 — Python Task 1.

## Features

- **Add** a contact (name, phone, email) with input validation
- **View** all contacts in a readable, sorted table
- **Search** by full or partial name (case-insensitive)
- **Update** any field of an existing contact
- **Delete** a contact (with confirmation)
- **Persistence**: contacts are saved to `contacts.csv` after every change, so
  they're still there the next time you run the program
- **Error handling**: invalid phone/email formats are rejected with a helpful
  message instead of crashing; a missing/corrupt data file starts a fresh,
  empty contact book instead of raising an exception

## Setup

Requires Python 3.7+. No external packages needed (only the standard library).

```bash
python3 contact_book.py
```

On first run it will look for `contacts.csv` in the same folder. A sample file
with 5 contacts is included so you can try Search/View/Update/Delete right
away.

## File overview

| File | Purpose |
|---|---|
| `contact_book.py` | Main program — menu loop and all features |
| `contacts.csv` | Sample data (5 contacts) |
| `session_output.txt` | A captured terminal session showing View → Add → Search → Exit |

## Validation rules

- **Phone**: digits, spaces, `+`, `-`, `()`, 7–20 characters
- **Email**: must match `name@domain.tld`

Both are re-prompted until valid on Add; on Update, an invalid entry is
rejected and the previous value is kept.

## Notes on design decisions

- Data is stored as CSV (as suggested in the task brief) with a header row, so
  it's easy to open in Excel/Sheets for a quick look.
- All I/O and validation logic are split into small functions to keep `main()`
  readable and to make each piece independently testable.
- Search matches are on **name only** (per the requirement); it is
  case-insensitive and matches partial substrings anywhere in the name.

## Screenshots

See `session_output.txt` for a full captured terminal transcript demonstrating
the app running end-to-end (this environment has no GUI, so a text transcript
is provided in place of image screenshots — see the note in the top-level
`HOW_TO_PUBLISH.md` for how to grab real screenshots on your machine before
submitting).
