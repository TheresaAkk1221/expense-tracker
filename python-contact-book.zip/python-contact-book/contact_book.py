"""
Contact Book - A simple command-line contact management application.

Inovegen Internship Program 2026 - Week 1, Python Task 1

Features:
 - Add contacts (name, phone, email)
 - View all contacts
 - Search by name / partial name
 - Update a contact
 - Delete a contact
 - Persist data to a CSV file so contacts survive between runs
 - Basic input validation and error handling throughout
"""

import csv
import os
import re

DATA_FILE = "contacts.csv"
FIELDNAMES = ["name", "phone", "email"]


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def load_contacts(filepath=DATA_FILE):
    """Load contacts from a CSV file into a list of dicts.

    If the file does not exist yet, an empty list is returned instead of
    raising an error, since a brand-new install should still work.
    """
    contacts = []
    if not os.path.exists(filepath):
        return contacts

    try:
        with open(filepath, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Guard against malformed rows (missing keys) rather than crashing.
                if all(key in row for key in FIELDNAMES):
                    contacts.append(row)
    except (OSError, csv.Error) as exc:
        print(f"Warning: could not read '{filepath}' ({exc}). Starting with an empty contact book.")
    return contacts


def save_contacts(contacts, filepath=DATA_FILE):
    """Write the full list of contacts back to the CSV file."""
    try:
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()
            writer.writerows(contacts)
    except OSError as exc:
        print(f"Error: could not save contacts to '{filepath}' ({exc}).")


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

PHONE_RE = re.compile(r"^\+?[0-9()\-\s]{7,20}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def is_valid_phone(phone):
    return bool(PHONE_RE.match(phone.strip()))


def is_valid_email(email):
    return bool(EMAIL_RE.match(email.strip()))


def prompt_nonempty(label):
    """Keep asking until the user provides a non-empty value."""
    while True:
        value = input(f"{label}: ").strip()
        if value:
            return value
        print("This field can't be empty. Please try again.")


def prompt_phone():
    while True:
        value = input("Phone: ").strip()
        if is_valid_phone(value):
            return value
        print("That doesn't look like a valid phone number (digits, spaces, +, -, () only, 7-20 chars).")


def prompt_email():
    while True:
        value = input("Email: ").strip()
        if is_valid_email(value):
            return value
        print("That doesn't look like a valid email address (expected something like name@example.com).")


# ---------------------------------------------------------------------------
# Core features
# ---------------------------------------------------------------------------

def add_contact(contacts):
    print("\n-- Add Contact --")
    name = prompt_nonempty("Name")
    phone = prompt_phone()
    email = prompt_email()

    contacts.append({"name": name, "phone": phone, "email": email})
    save_contacts(contacts)
    print(f"Added '{name}'.")


def view_contacts(contacts):
    print("\n-- All Contacts --")
    if not contacts:
        print("(No contacts saved yet.)")
        return

    # Simple aligned table output.
    name_w = max(len("Name"), max(len(c["name"]) for c in contacts))
    phone_w = max(len("Phone"), max(len(c["phone"]) for c in contacts))
    print(f"{'Name'.ljust(name_w)}  {'Phone'.ljust(phone_w)}  Email")
    print("-" * (name_w + phone_w + 30))
    for c in sorted(contacts, key=lambda c: c["name"].lower()):
        print(f"{c['name'].ljust(name_w)}  {c['phone'].ljust(phone_w)}  {c['email']}")


def search_contacts(contacts):
    print("\n-- Search Contacts --")
    if not contacts:
        print("(No contacts saved yet.)")
        return

    query = input("Enter a name or partial name to search for: ").strip().lower()
    if not query:
        print("Search cannot be empty.")
        return

    matches = [c for c in contacts if query in c["name"].lower()]
    if not matches:
        print(f"No contacts matched '{query}'.")
        return

    print(f"Found {len(matches)} match(es):")
    for c in matches:
        print(f"  - {c['name']} | {c['phone']} | {c['email']}")


def find_contact_index_by_name(contacts, name):
    """Return the index of the first exact (case-insensitive) name match, or None."""
    for i, c in enumerate(contacts):
        if c["name"].lower() == name.lower():
            return i
    return None


def update_contact(contacts):
    print("\n-- Update Contact --")
    if not contacts:
        print("(No contacts saved yet.)")
        return

    name = input("Enter the exact name of the contact to update: ").strip()
    idx = find_contact_index_by_name(contacts, name)
    if idx is None:
        print(f"No contact found named '{name}'.")
        return

    contact = contacts[idx]
    print(f"Editing '{contact['name']}'. Press Enter to keep the current value.")

    new_name = input(f"Name [{contact['name']}]: ").strip()
    new_phone = input(f"Phone [{contact['phone']}]: ").strip()
    new_email = input(f"Email [{contact['email']}]: ").strip()

    if new_name:
        contact["name"] = new_name
    if new_phone:
        if is_valid_phone(new_phone):
            contact["phone"] = new_phone
        else:
            print("Invalid phone format - keeping the previous value.")
    if new_email:
        if is_valid_email(new_email):
            contact["email"] = new_email
        else:
            print("Invalid email format - keeping the previous value.")

    save_contacts(contacts)
    print("Contact updated.")


def delete_contact(contacts):
    print("\n-- Delete Contact --")
    if not contacts:
        print("(No contacts saved yet.)")
        return

    name = input("Enter the exact name of the contact to delete: ").strip()
    idx = find_contact_index_by_name(contacts, name)
    if idx is None:
        print(f"No contact found named '{name}'.")
        return

    confirm = input(f"Are you sure you want to delete '{contacts[idx]['name']}'? (y/n): ").strip().lower()
    if confirm == "y":
        removed = contacts.pop(idx)
        save_contacts(contacts)
        print(f"Deleted '{removed['name']}'.")
    else:
        print("Cancelled.")


# ---------------------------------------------------------------------------
# Menu / entry point
# ---------------------------------------------------------------------------

MENU = """
========== CONTACT BOOK ==========
1. Add contact
2. View all contacts
3. Search contacts
4. Update contact
5. Delete contact
6. Exit
===================================
"""


def main():
    contacts = load_contacts()
    print("Welcome to Contact Book!")
    print(f"Loaded {len(contacts)} contact(s) from '{DATA_FILE}'.")

    while True:
        print(MENU)
        choice = input("Choose an option (1-6): ").strip()

        if choice == "1":
            add_contact(contacts)
        elif choice == "2":
            view_contacts(contacts)
        elif choice == "3":
            search_contacts(contacts)
        elif choice == "4":
            update_contact(contacts)
        elif choice == "5":
            delete_contact(contacts)
        elif choice == "6":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 6.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted. Goodbye!")
